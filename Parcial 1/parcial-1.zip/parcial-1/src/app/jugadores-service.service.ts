import { Injectable } from '@angular/core';
import { Jugador } from './jugador.model';

@Injectable({
  providedIn: 'root',
})
export class JugadoresService {
  private jugadores: Jugador[] = [];

  getJugadores(): Jugador[] {
    return this.jugadores;
  }

  agregarJugador(jugador: Jugador): string {
    if (this.jugadores.length < 23) {
      this.jugadores.push(jugador);
      return 'Jugador agregado exitosamente.';
    } else {
      return 'No se pueden agregar más de 23 jugadores.';
    }
  }

  eliminarJugador(jugador: Jugador): void {
    const index = this.jugadores.findIndex((j) => j === jugador);
    if (index !== -1) {
      this.jugadores.splice(index, 1);
    }
  }
}
