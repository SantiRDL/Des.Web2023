import { Component, OnInit } from '@angular/core';
import { JugadoresService } from 'src/app/jugadores-service.service';
import { Jugador } from 'src/app/jugador.model';

@Component({
  selector: 'app-jugadores-list',
  templateUrl: './jugadores-list.component.html',
  styleUrls: ['./jugadores-list.component.css'],
})
export class JugadoresListComponent implements OnInit {
  jugadores: Jugador[] = [];

  constructor(private jugadoresService: JugadoresService) {}

  ngOnInit(): void {
    this.jugadores = this.jugadoresService.getJugadores();
  }
}

