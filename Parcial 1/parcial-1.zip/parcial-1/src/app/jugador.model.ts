export interface Jugador {
    nombre: string;
    foto: string; // Ruta de la foto en el sistema de archivos
    posicion: string;
  }
  