import { Component } from '@angular/core';
import { JugadoresService } from 'src/app/jugadores-service.service';
import { Jugador } from 'src/app/jugador.model';

@Component({
  selector: 'app-crear-jugador',
  templateUrl: './crear-jugador.component.html',
  styleUrls: ['./crear-jugador.component.css'],
})
export class CrearJugadorComponent {
  nuevoJugador: Jugador = { nombre: '', foto: '', posicion: '' };

  constructor(private jugadoresService: JugadoresService) {}

  agregarJugador() {
    this.jugadoresService.agregarJugador(this.nuevoJugador);
    this.nuevoJugador = { nombre: '', foto: '', posicion: '' };
  }
}

