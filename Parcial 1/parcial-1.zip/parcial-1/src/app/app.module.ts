import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { JugadoresListComponent } from './jugadores-list/jugadores-list.component';
import { JugadorDetailComponent } from './jugador-detail/jugador-detail.component';
import { CrearJugadorComponent } from './crear-jugador/crear-jugador.component';
import { JugadoresService } from 'src/app/jugadores-service.service';

@NgModule({
  declarations: [
    AppComponent,
    JugadoresListComponent,
    JugadorDetailComponent,
    CrearJugadorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [JugadoresService],
  bootstrap: [AppComponent]
})
export class AppModule { }
